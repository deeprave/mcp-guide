# Original Files Archive

This archive contains the original versions of installed files.

**DO NOT MODIFY** the contents of this archive.

The installer uses these files to:
- Detect if you have made changes to installed files
- Apply smart updates that preserve your modifications
- Generate diffs between original and new versions

If this archive is modified or deleted, the installer cannot determine
which changes are yours and will replace files without attempting to
merge your modifications.
